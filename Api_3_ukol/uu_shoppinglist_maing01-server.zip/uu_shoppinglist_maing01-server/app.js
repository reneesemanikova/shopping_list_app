const appServer = require("uu_appg01_server");

appServer.start();
